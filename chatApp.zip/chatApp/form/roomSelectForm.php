<?php
class RoomSelectForm {
    function retInputErrorText($array) {
        $html = "";
        // エラー表示処理
        if (!empty($array)) {
            foreach($array as $result) {
                $html .= $result . "<br>";
            }
        }
        return $html;
    }

    function userInfoSetting($userInfo) {
        $html = "";

        // アイコン表示処理
        $imgPath = "../images/index/";
        $imageArray = array(
            0=>'ne', 1=>'usi', 2=>'tora', 3=>'u', 4=>'tatu',
            5=>'mi', 6=>'uma', 7=>'hituji', 8=>'saru', 9=>'tori',
            10=>'inu', 11=>'i'
        );
        $iconId = $userInfo[0]['SelectedIcon'];
        $html .= "<div id='userIcon'>";
        $html .= "<img src=" . "${imgPath}" . $imageArray[$iconId] . ".png" . ">";
        $html .= "</div>";

        // ユーザー詳細取得処理
        $html .= "<div id='UserInfoWrap'>";
            $html .= "<div class='userInfoRow'>";
                $html .= "<div class='userInfoHeading'>Name :</div>";
                $html .= "<div class='userInfoItem'>" . $userInfo[0]['userName'] . "</div>";
            $html .= "</div>";

            $html .= "<div class='userInfoRow'>";
                $html .= "<div class='userInfoHeading'>Age :</div>";
                $html .= "<div class='userInfoItem'>" . $userInfo[0]['ageSelect'] . "</div>";
            $html .= "</div>";

            $html .= "<div class='userInfoRow'>";
                $html .= "<div class='userInfoHeading'>Gender :</div>";
                $gender = ($userInfo[0]['gender'] == 'male') ? "男" : "女";
                $html .= "<div class='userInfoItem'>" . $gender . "</div>";
            $html .= "</div>";
        $html .= "</div>";
        return $html;
    }

    function inputDetailText($userName) {
        $html = "";
        if ($userName == '') {
            $html .= "<input type='text' name='userName' class='inputText' placeholder='ユーザー名を入力'>";
        } else {
            $html .= "<input type='text' name='userName' value='" . $userName. "' class='inputText' placeholder='ユーザー名を入力'>";
        }
        return $html;
    }

    function createGenderRadio($gender) {
        $html = "";
        $html .= "<ul>";
        $html .= "<li>性別 : </li>";
        if ($gender == 'male') {
            $html .= "<li><input type='radio' name='gender' value='male' checked>男性</li>";
            $html .= "<li><input type='radio' name='gender' value='female'>女性</li>";
        } else {
            $html .= "<li><input type='radio' name='gender' value='male'>男性</li>";
            $html .= "<li><input type='radio' name='gender' value='female' checked>女性</li>";
        }
        $html .= "</ul>";
        return $html;
    }

    function createAgeSelect($ageSelect) {
        $html = "";
        $html .= "年齢 : ";
        $html .= "<select name='ageSelect'>";
        for ($i=10; $i<=80; $i++) {
            if ($ageSelect == $i) {
                $html .= "<option value='" . $i . "' selected>${i}</option>";
            } else {
                $html .= "<option value='" . $i . "'>${i}</option>";
            }
        }
        $html .= "</select>";
        return $html;
    }
}
?>