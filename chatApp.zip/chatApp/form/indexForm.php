<?php
class indexForm {
    function retInputErrorText($array) {
        $html = "";
        // エラー表示処理
        if (!empty($array)) {
            foreach($array as $result) {
                $html .= $result . "<br>";
            }
        }
        return $html;
    }

    function iconImgSetting() {
        $html = "";
        $imgPath = /*__DIR__ . "/.. / */ "images/index/";
        $imageArray = array(
            array(0=>'ne', 1=>'usi', 2=>'tora', 3=>'u', 4=>'tatu'),
            array(5=>'mi', 6=>'uma', 7=>'hituji', 8=>'saru', 9=>'tori'),
            array(10=>'inu', 11=>'i')
        );
        $j = 0;
        for ($i=0; $i<count($imageArray); $i++) {
            $html .= "<div class='iconRowInner'>";
            foreach($imageArray[$i] as $key => $value) {
                $html .= "<div class='iconImg' id='" . $key . "' >";
                $html .= "<img src=" . "${imgPath}" . $imageArray[$i][$j] . ".png" . ">";
                $html .= "</div>";
                $j++;
            }
            $html .= "</div>";
        }
        $html .= "<input type='hidden' class='SelectedIcon' name='SelectedIcon' value=''>";
        return $html;
    }

    function inputDetailText($userName) {
        $html = "";
        if ($userName == '') {
            $html .= "<input type='text' name='userName' class='inputText' placeholder='ユーザー名を入力'>";
        } else {
            $html .= "<input type='text' name='userName' value='" . $userName. "' class='inputText' placeholder='ユーザー名を入力'>";
        }
        return $html;
    }

    function createGenderRadio($gender) {
        $html = "";
        $html .= "<ul>";
        $html .= "<li>性別 : </li>";
        if ($gender == 'male') {
            $html .= "<li><input type='radio' name='gender' value='male' checked>男性</li>";
            $html .= "<li><input type='radio' name='gender' value='female'>女性</li>";
        } else {
            $html .= "<li><input type='radio' name='gender' value='male'>男性</li>";
            $html .= "<li><input type='radio' name='gender' value='female' checked>女性</li>";
        }
        $html .= "</ul>";
        return $html;
    }

    function createAgeSelect($ageSelect) {
        $html = "";
        $html .= "年齢 : ";
        $html .= "<select name='ageSelect'>";
        for ($i=10; $i<=80; $i++) {
            if ($ageSelect == $i) {
                $html .= "<option value='" . $i . "' selected>${i}</option>";
            } else {
                $html .= "<option value='" . $i . "'>${i}</option>";
            }
        }
        $html .= "</select>";
        return $html;
    }
}
?>