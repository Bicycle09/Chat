$(function(){
    $(".iconImg").click(function() {
		if(!($(this).hasClass('iconActive'))){
			$(".iconImg").removeClass('iconActive');
			$(this).addClass('iconActive');
			$('.SelectedIcon').attr('value' , $(this).attr('id'));
        }
    });
});