$(function(){
    $("#roomChangeButtonWrap").find('li').click(function() {
	    	if (	$(this).find('div').attr('id') == 'roomSearchButton') {
	    		$('#roomSetting').css('display', 'none');
	    		$('#roomSearch').css('display', 'block');
	    	} else if ($(this).find('div').attr('id') == 'roomMakeButton') {
	    		$('#roomSetting').css('display', 'block');
	    		$('#roomSearch').css('display', 'none');
	    	}
    });
});