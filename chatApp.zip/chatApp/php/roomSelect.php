<?php
    require_once (__DIR__ . "/../controller/roomSelectController.inc");
?>

<?php
    $cont = new RoomSelectController($_POST);
    $userInfo = $cont->getCookieInfo();
?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<script type="text/javascript" src="../js/jquery/jquery.min.js"></script>
	<script type="text/javascript" src="../js/roomSelect.js"></script>
	<link rel="stylesheet" href="../css/roomSelect.css" type="text/css">
	<link rel="stylesheet" href="../css/common.css" type="text/css">
</head>
<body>
<form method='post' name='indexForm' action="#">

<div id="container">
    <div id="header">
    		<div id="headerWrap">
    			<div id="headerImg"></div>
    			<div id="headerText">自作チャット（作成中）</div>
    		</div>
    </div>

    <div id='contents'>
        <div id="userShow">
        		<div id="userShowWrap">
        			<div id="userInfo">
        				<?php echo $userInfo ?>
        			</div>
        		</div>
        	</div>

        	<div id="room">
        		<div id="roomChange">
        			<div id="roomChangeButtonWrap">
        				<ul>
        					<li><div id="roomMakeButton">ルーム作成</div></li><li><div id="roomSearchButton">ルーム検索</div></li>
        				</ul>
        			</div>
        		</div>
        		<div id="roomSetting">
        			<div id="note">注意書き</div>
        			<div id="makeRoomWrap">
        				<div class="roomMakeDetailRow">
        					<div class="roomMakeDetailHeading">部屋名</div>
        					<div class="roomMakeDetailInput">
        						<input type='text' name='roomName' class='inputText' placeholder='部屋名を入力  ※必須'>
        					</div>
        				</div>
        				<div class="roomMakeDetailRow">
        					<div class="roomMakeDetailHeading">人数</div>
        					<div class="roomMakeDetailInput">
        						<select name='roomNumberOfPeople'>
        							<?php
        							for ($i=2; $i<12; $i++) {
        							    echo "<option value='" . $i . "'>$i</option>";
        							}
        							?>
        						</select>
        					</div>
        				</div>
        				<div class="roomMakeDetailRow">
        					<div class="roomMakeDetailHeading">ルームキー</div>
        					<div class="roomMakeDetailInput">
        						<input type='text' name='roomKey' class='inputText' placeholder='ルームキーを入力'>
        					</div>
        				</div>
        				<div class="roomMakeDetailRow">
        					<div class="roomMakeDetailHeading">コメント</div>
        					<div class="roomMakeDetailInput">
        						<input type='text' name='roomComent' class='inputText' placeholder='コメントを入力'>
        					</div>
        				</div>
        				<div class="roomMakeDetailRow">
        				<div class="roomMakeDetailHeading"></div>
                				<div class="roomMakeDetailInput">
                					<div class="roomSettingButton">
                						<input type="submit" name='makeRoomBtn' value='部屋を作成する' class='roomSettingButtonDedign'>
                					</div>
                				</div>
        				</div>
        			</div>
        		</div>

        		<div id="roomSearch">
        			ルーム検索
        		</div>

        		<div id="roomList">
        			<div class='roomListRow'>
        				<div class='roomTitle'>ルームタイトル</div>
        				<div class='roomUserRow'>
        					<div class='roomInUser'>
        						<div class='roomInUserImage'><img src='../images/index/ne.png'></div>
        						<div class='userName'>ねずみ</div>
        					</div>
        					<div class='roomInUser'>
        						<div class='roomInUserImage'><img src='../images/index/ne.png'></div>
        						<div class='userName'>あああああいいいいいうううううえええええ</div>
        					</div>
        				</div>

        				<div class='roomNum'>4/4</div>
        				<div class='roomInBtn'><input type='submit' value='入室'></div>
        			</div>
        		</div>
        	</div>
	</div>

	<div id="footer">
	<div id="footerWrap">
		<div id="footerrImg"></div>
		<div id="footerText">Copyright © 2018 NoName All Rights Reserved.</div>
	</div>
</div>
</div>



</form>
</body>
</html>